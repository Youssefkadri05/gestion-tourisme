import React, { Component } from 'react';

class AboutApp extends Component {
  render() {
    return (
      <div className="container mt-5">
        <p>je suis About</p>
      </div>
    );
  }
}

export default AboutApp;
