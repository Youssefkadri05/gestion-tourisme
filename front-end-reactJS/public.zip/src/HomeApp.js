import React, { Component } from 'react';

class HomeApp extends Component {
  render() {
    return (
      <div className="container mt-5">
        <p>je suis Home</p>
      </div>
    );
  }
}

export default HomeApp;
