const express = require('express');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  // Vérifier si les informations d'identification sont correctes
  if (username === 'youssef' && password === 'kadri') {
    // Générer un JWT
    const token = jwt.sign({ username }, 'secret_key');
    res.json({ token });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
});

app.get('/api/protected', (req, res) => {
  const token = req.headers.authorization.split(' ')[1];

  try {
    const decoded = jwt.verify(token, 'secret_key');
    res.json({ message: `Welcome ${decoded.username}!` });
  } catch (error) {
    res.status(401).json({ message: 'Unauthorized' });
  }
});

app.listen(8000, () => {
  console.log('Server started on port 8000');
});
